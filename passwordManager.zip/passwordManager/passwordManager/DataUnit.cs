﻿namespace passwordManager
{
    public abstract class DataUnit
    {
        public Category Category { get; set; }
        
        public int Id { get; set; }
    }
}