﻿namespace passwordManager
{
    public class Password
    {
    }
}