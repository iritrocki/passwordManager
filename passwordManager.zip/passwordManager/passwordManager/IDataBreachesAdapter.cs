﻿using System.Collections.Generic;

namespace passwordManager
{
    public interface IDataBreachesAdapter
    {
        List<string> AdaptData();
    }
}